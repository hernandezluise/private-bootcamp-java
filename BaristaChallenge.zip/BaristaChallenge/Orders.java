import java.util.ArrayList;

public class Orders {
    
    private String name;
    //private double total;
    private boolean ready;

    private ArrayList<Item> item;
    
    // Constructer
    public Orders() {
    	this.name = "Guest";
    	this.item = new ArrayList<Item>();
    }
    

    // Overloaded Constructor
    public Orders(String name) {
    	this.name = name;
    	this.item = new ArrayList<Item>();
    }
    

    // Order methods
    public void addItme(Item items) {
    	item.add(items);
    }
    
    public String getStatusMessage() {
    	if(this.ready) {
    		return "Your order is ready";
    	}
    	return "Thank you for waiting, your order will be ready soon.";
    }
    
    public double getOrderTotal() {
    	double total = 0;
    	for(Item item: item) {
    		total += item.getPrice();
    	}
    	return total;
    }
    
    public void display() {
    	System.out.println("Customer Name: " + this.name);
    	for(Item item : item) {
    		System.out.println("Total: $" + getOrderTotal());
    	}
    	
    }
    

    // Getters and Setters
    public String getName() {
    	return this.name;
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    public void setReady(boolean ready) {
    	this.ready = ready;
    }
    
    public ArrayList<Item> getItems(){
    	return this.item;
    }
    
    public void setItem(ArrayList<Item> item) {
    	this.item = item;
    }
}
package com.luishernandez.fruityloops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityLoops1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

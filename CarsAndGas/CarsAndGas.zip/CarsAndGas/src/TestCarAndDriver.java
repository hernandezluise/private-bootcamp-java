

public class TestCarAndDriver {
    public static void main(String[] args) {
    	Driver luis = new Driver();
    	luis.decreaseGas();
    	luis.decreaseGas();
    	luis.decreaseGas();
    	luis.decreaseGas();
    	
    	
    	luis.boost();
    	
    	luis.refuel();
    	luis.refuel();
    	luis.refuel();
    }
}

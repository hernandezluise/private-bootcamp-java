
class Car {
    public int gasLevel = 10;

    public void gasLevelStatus(){
    	//int gasLevel = 10;
       System.out.println("Current gas level: " + gasLevel + "/10");
    }
}

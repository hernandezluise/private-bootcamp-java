
public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat bat1 = new Bat();
		System.out.println("Energy level check");
		
		bat1.energyStatus();

		bat1.attackTown();
		bat1.attackTown();
		bat1.attackTown();
		
		bat1.eatHumans();
		bat1.eatHumans();
		
		bat1.fly();
		bat1.fly();
		
		
	}

}

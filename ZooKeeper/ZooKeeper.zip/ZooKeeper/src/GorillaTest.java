
public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla gorilla1 = new Gorilla();
		
		
		gorilla1.throwThings();
		gorilla1.throwThings();
		gorilla1.throwThings();
		
		gorilla1.eatBananas();
		gorilla1.eatBananas();
		
		gorilla1.climb();
		
	}

}
